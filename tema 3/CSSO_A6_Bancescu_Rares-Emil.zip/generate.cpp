#include <iostream>
#include <windows.h>
int totalIncome = 0;
int totalPayments = 0;

void writeInFile(const char *path, char *text)
{

    HANDLE handle;
    BOOL ErrorFlag;
    DWORD NumberOfLetters = (DWORD)strlen(text);
    DWORD NumberOfLettersWritten = 0;
    handle = CreateFileA(path, FILE_APPEND_DATA, NULL, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (handle == INVALID_HANDLE_VALUE)
    {
        printf("Eroare la deschiderea fisierului");
        CloseHandle(handle);
    }

    ErrorFlag = WriteFile(handle, text, NumberOfLetters, &NumberOfLettersWritten, NULL);

    if (ErrorFlag == 0)
    {

        printf("Nu s e putut scrie in fisier");
        CloseHandle(handle);
    }
    else
    {
        if (NumberOfLetters != NumberOfLettersWritten)
        {
            printf("Nu s au putut scrie toate literele");
            CloseHandle(handle);
        }
        else
        {
            // printf("S-au scris toate literele");
            CloseHandle(handle);
        }
    }
}

void readFromFile(char *param)
{
    HANDLE handle;
    char path[] = "C:\\Facultate\\CSSO\\Laboratoare\\Week3\\Reports\\Daily\\";
    strcat(path, param);

    printf("%s\n", path);
    handle = CreateFileA((LPCSTR)path, GENERIC_READ, NULL, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (handle == INVALID_HANDLE_VALUE)
    {

        printf("Eroare la deschiderea fisierului");
        CloseHandle(handle);
    }
    else
    {
        DWORD read;
        LARGE_INTEGER fileSize;
        char readBuffer[100000] = {0};
        int result;
        if (GetFileSizeEx(handle, &fileSize))
        {
            result = fileSize.LowPart;
        }
        if (ReadFile(handle, readBuffer, (result / sizeof(char)), &read, NULL) == FALSE)
        {
            printf("Eroare la citirea din fisier");
        }
        else
        {
            // we have the informations in the buffer
            if (strstr(readBuffer, "income"))
            {
                totalIncome += atoi(readBuffer);
            }
            else
            {
                totalPayments += atoi(readBuffer);
            }
        }

        CloseHandle(handle);
    }
}

void readFromMemoryAndCompare()
{
    HANDLE mapping;
    TCHAR fileName[] = TEXT("cssohw3management");
    LPCTSTR read;

    mapping = OpenFileMapping(FILE_MAP_ALL_ACCESS, FALSE, fileName);

    if (mapping == INVALID_HANDLE_VALUE)
    {
        printf("Eroare la deschiderea maparii in memorie");
        CloseHandle(mapping);
    }
    else
    {
        read = (LPTSTR)MapViewOfFile(mapping, FILE_MAP_ALL_ACCESS, 0, 0, 256);
        if (read == NULL)
        {
            printf("Eroare la obtinerea adresei memoriei");
            UnmapViewOfFile(read);
        }
        else
        {
            printf("%s", read);
            char textToWriteInFile[100];

            if (atoi(read) == (totalIncome - totalPayments))
            {
                strcpy(textToWriteInFile, "Raport generat cu success!");
                writeInFile("C:\\Facultate\\CSSO\\Laboratoare\\Week3\\Reports\\logs.txt", textToWriteInFile);
            }

            else
            {
                strcpy(textToWriteInFile, "Ai o greșeală la generarea raportului");
                writeInFile("C:\\Facultate\\CSSO\\Laboratoare\\Week3\\Reports\\logs.txt", textToWriteInFile);
            }

            UnmapViewOfFile(read);
        }
        CloseHandle(mapping);
    }
}

void writeLogs()
{
    char fileNames[1000][30];
    int index = 0;
    WIN32_FIND_DATA data;
    HANDLE handle;
    handle = FindFirstFile("C:\\Facultate\\CSSO\\Laboratoare\\Week3\\Reports\\Daily\\*", &data);
    if (handle == INVALID_HANDLE_VALUE)
    {
        printf("Eroare");
        FindClose(handle);
    }
    else
    {
        do
        {
            sprintf(fileNames[index], "%s", data.cFileName);
            index++;
        } while (FindNextFile(handle, &data));
        FindClose(handle);
    }

    for (int i = 0; i < index; i++)
    {
        // printf("%s\n",fileNames[i]);
        readFromFile(fileNames[i]);
    }
    char textToWriteInFile[200];
    strcpy(textToWriteInFile, "");
    sprintf(textToWriteInFile, "S-au facut incasari de %d\nS-au facut cheltuieli de %d\n S-a realizat un profit de %d\n", totalIncome, totalPayments, totalIncome - totalPayments);
    writeInFile("C:\\Facultate\\CSSO\\Laboratoare\\Week3\\Reports\\logs.txt", textToWriteInFile);
    readFromMemoryAndCompare();
}

int main()
{
    writeLogs();
    return 0;
}